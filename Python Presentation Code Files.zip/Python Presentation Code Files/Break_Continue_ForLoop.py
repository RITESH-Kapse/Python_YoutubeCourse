
#Break Statement Example

''' Print the output where we find the key'''

key_location = "chair"

locations = ["garage", "living room", "chair", "closet"]

for i in locations:
    if i ==  key_location:
        print("key is found in ", i)
        break # Once you find the key location, not required to check other remaining locations.
    else:
        print("key is not found in ", i)


#Continue Statement Example

'''

Print the sqaure of numbers from 1 to 7 EXCEPT even numbers.

'''

''' Code :

for i in range(1,8):
    if i%2==0:
        continue  # here if i is even, it wont execute print statement and will loop back to for loop.
    print(i*i)

'''