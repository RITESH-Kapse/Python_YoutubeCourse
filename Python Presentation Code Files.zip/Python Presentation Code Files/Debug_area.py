
base = 10
height = 20

area = 1/2 * (base*height)

print("Area of mentioned traingle is ", area)