'''
Block of code that performs specific task are functions.
Ex : Dish Washer , Washing Machine etc

'''

#Problem Statement
'''
Ex : If there are multiple lists, and we need to find total of each list.
    
    We can use for loop multiple times and get the solution. But we are repeating code here.
    To follow DRY ( Donot repeat yourself) , we need to use functions.

'''

'''
#Normal Code : 

list1 = [2,4,6,88,8,8]
list2 = [1,9,99,5,44,9]

total = 0
for i in list1:
    total = total +i

print( " total of list1 is" , total)

total = 0
for i in list2:
    total = total +i

print( " total of list2 is" , total)
'''

# Using functions -- def is special keywors that tell python that we are creating function.

list1 = [2,4,6,88,8,8]
list2 = [1,9,99,5,44,9]

def calculate_total(inp):
    total = 0
    for item in inp:
        total = total + item
    return total

#Here  "inp" - function arguments , "total" -- return value

list1_total = calculate_total(list1)
list2_total = calculate_total(list2)

print(list1_total)
print(list2_total)
