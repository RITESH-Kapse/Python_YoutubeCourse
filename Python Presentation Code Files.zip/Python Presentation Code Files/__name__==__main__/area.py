def calculate_triangle_area(base,height):
    print("__name__: " ,__name__)
    return 1/2 * (base*height)


# Like other languages C, C++ and Java, they have main function as entry point. Similiarly this is entry point for python code.

if __name__ == "__main__":
    print("I am in area.py")
    a =  calculate_triangle_area(10,20)
    print("Area: ", a)