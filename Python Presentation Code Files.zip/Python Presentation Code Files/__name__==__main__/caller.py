import area

print("I am in caller.py")
a = area.calculate_triangle_area(10,10)
print("Area: ", a)