#Exceptions :
    #Errors detected at the time of program execution

x = input("Enter the number1: ")
y = input("Enter the numner2: ")

try:
    z = int(x) / int(y)
except Exception as e:
    print("Exception occured: ",e)
    z = None

print("Division is :", z)



#All python buildin exceptions : https://docs.python.org/3/library/exceptions.html


'''

If we wanted to check the exception name and then make specific error code and not generic:

x = input("Enter the number1: ")
y = input("Enter the numner2: ")

try:
    z = int(x) / int(y)
except Exception as e:
    print("Exception occured: ",type(e).__name__)
    z = None

print("Division is :", z)


'''

# Example : When we forgot to convert input string to integer : it will give TypeError

# x = input("Enter the number1: ")
# y = input("Enter the numner2: ")

# try:
#     z = (x) / int(y)
# except Exception as e:
#     print("Exception occured: ",type(e).__name__)
#     z = None

# print("Division is :", z)




#Try except else finally 

'''
try:
    # Some Code
except:
    # Executed if error in the
    # try block
else:
    # execute if no exception
finally:
    # Some code .....(always executed)

'''

# Example :
# # Python program to demonstrate finally
	
# # No exception Exception raised in try block
# try:
# 	k = 5//0 # raises divide by zero exception.
# 	print(k)
	
# # handles zerodivision exception	
# except ZeroDivisionError:
# 	print("Can't divide by zero")
		
# finally:
# 	# this block is always executed
# 	# regardless of exception generation.
# 	print('This is always executed')
