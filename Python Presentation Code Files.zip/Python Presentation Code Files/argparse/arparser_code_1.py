####  Processing Command Line Arguments using argparse module
# -h is default argument.
# Arguments - Positional , Optional arguments
# Problem Statement - Take two numbers as input and perform
# operations

import argparse

if __name__ == "__main__":
    
    parser = argparse.ArgumentParser()
    
    # Below are positional arguments
    parser.add_argument("number1", help="first number")
    parser.add_argument("number2", help="second number")
    #parser.add_argument("operation", help="operation")

    # we also can restrict choices of arguments as
    parser.add_argument("--operation", help="operation", choices=["add","substract","multiply"])
    
    #Optional argument
    # parser.add_argument("--number2", help="second number")

    args = parser.parse_args()
    
    # Below checks if arguments passed are correctly assigned.
    print(args.number1)
    print(args.number2)
    print(args.operation)
    
    n1 = int(args.number1)
    n2 = int(args.number2)
    
    result = None
    if args.operation == "add":
        result = n1+n2
    elif args.operation == "subtract":
        result = n1-n2
    elif args.operation == "multiply":
        result = n1*n2
    else:
        print("unsupported operation")
        
    print(result)