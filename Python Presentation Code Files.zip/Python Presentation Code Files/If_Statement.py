'''
Problem Statement : Program to check number is even or odd.
Note : input() function takes user input which can be used as input to the code.

'''
#Code : You can add breakpoint and check each step output.

num = input("Enter the number: ") # It will take input from user as string .
num = int(num) 

if num%2==0:
    print("Number is even")
else:
    print("Number is odd")