#Numbers
'''
#Addition
12+34


#division
3/4

#Floor Division
4//3

#Find reminder
11%2

#Find 3 to the power of 2.
3**2

'''

#Strings
'''

text = "python code"
print(text)

print(text[0])
print(text[7])
print(text[10])

# string slicing
#range will be index 0 to index 4 (0 included ,5 excluded)

print(text[0:5])

# String concatination

var1 ="python"
var2 = "code"

print(var1+' '+var2)

# String and number addition
# Use str() function to convert interger to string

var1 = "Hello"
var2 = 50

print(var1 + ' ' + str(var2))





'''