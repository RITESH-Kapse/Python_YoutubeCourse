#How to skip particular test
import mathlib
import pytest


def test_calc_total():
    total = mathlib.calc_total(4,5)
    assert total == 9

@pytest.mark.skip(reason = "Example on how to skip test")
def test_cal_multiply_skip():
    result = mathlib.cal_multiply(4,5)
    assert result == 20

'''
#To skip test if certain condition is met
import sys

@pytest.mark.skipif(sys.version_info < (3,8), reason = "Example on how to skip test with condition")
def test_cal_multiply_skipif():
    result = mathlib.cal_multiply(4,5)
    assert result == 20

'''


How to create Custom markers

Ex : Out of all tests run only tests with windows or mac

import mathlib
import pytest

@python.mark.windows
def test_windows_1():
    assert True

@python.mark.windows
def test_windows_2():
    assert True

@python.mark.mac
def test_mac_1():
    assert True

@python.mark.mac
def test_mac_2():
    assert True

# To run , use below command on console :
# To run test with custom markers created
#     pytest -m windows/mac -v

