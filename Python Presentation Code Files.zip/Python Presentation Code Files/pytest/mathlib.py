def calc_total(a,b):
    return a+b

def cal_multiply(a,b):
    return a*b

