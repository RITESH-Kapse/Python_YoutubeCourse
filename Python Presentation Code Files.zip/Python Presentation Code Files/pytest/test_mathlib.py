import mathlib

def test_calc_total():    
    total = mathlib.calc_total(4, 5)
    assert total == 9

def test_cal_multiply():
    result=mathlib.cal_multiply(4, 5)
    assert result == 20



