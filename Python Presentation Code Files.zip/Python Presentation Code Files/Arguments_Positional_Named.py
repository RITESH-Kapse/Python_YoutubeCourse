
#Note : We can pass two types of arguments , positional arguments and named arguments

# Positional Arguments
def sum(a,b):
    
    print("a: ", a)
    print("b: ", b)
    
    total = a+b
    return total

n = sum(5,6) # Here a=5 and b =6
print(n)


'''

# Named Arguments

def sum(a,b):

    print("a: ", a)
    print("b: ", b)
    
    total = a+b
    return total

n = sum(b=5,a=6) # Here b=5 and a =6
print(n)


'''

'''

# Default Arguments part 1    

def sum(a,b=0):

    print("a: ", a)
    print("b: ", b)
    
    total = a+b
    return total

n = sum(6) # Here b=5 and a =6
print(n)


'''


'''

# Default Arguments part 2    

def sum(a,b=0):

    print("a: ", a)
    print("b: ", b)
    
    total = a+b
    return total

n = sum(6,8) # Here b=8 and a =6
print(n)


'''