#Default Arguments
def sum(a,b=0):
    '''
    This can be multiline strings.
    Its documentation to explain the call of the function on what function does. Expected input,output.
    Inside ide, double quote thrice(""") and it will suggest the expected docstrings for function.
    '''

    """
    This function takes two arguments which are integers and it returns sum of them as output. 

    Returns:
        sum : addition of numbers

    """
    print("a: ", a)
    print("b: ", b)
    
    total = a+b
    return total

n = sum(6,8) # Here b=8 and a =6
print(n)