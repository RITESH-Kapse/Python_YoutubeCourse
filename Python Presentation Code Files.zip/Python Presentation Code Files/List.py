#Lists

# Creating a List with
# the use of multiple values
List = ["Let", "Training", "Start"]
print("\nList containing multiple values: ")
print(List)

# Creating a Multi-Dimensional List
# (By Nesting a list inside a List)
List2 = [['Let', 'Training'], ['Start']]
print("\nMulti-Dimensional List: ")
print(List2)

# accessing a element from the
# list using index number
print("Accessing element from the list")
print(List[0])
print(List[2])

# accessing a element using
# negative indexing
print("Accessing element using negative indexing")

# print the last element of list
print(List[-1])

# print the third last element of list
print(List[-3])



#append method used to add element in the end of the list.

List.append("extra")
print(List)


# insert method used to add element at desired location

List.insert(1,"NCG's")
print(List)

#List concatination
# Can only cancatenate lists and not different variable types with lists.
food = ["a","b","c"]
water = ["p","q","r"]

print(food + water)

