# Problem 1
'''
Problem statement :
    Store Monthly Expenses in a list and find out total expenses for all months.
    
'''
exp = [2340, 3500, 2100, 4100, 2980]

#Alternate Ways :
#total = sum(exp) #-- using sum function.
#total = exp[0] + exp[1] + exp[2] + exp[3] + exp[4] #-- for longer items in list, this is not good solution

total = 0
#using for loop
for item in exp:
    total = total + item

print(total)

# Another way we can write is 
'''
exp = [2340, 3500, 2100, 4100, 2980]
total = 0

for i in range(len(exp)):
    total = total + exp[i]
    
print(total)

Note : Here len(exp) with take actual length of list as integer number.


'''

# Problem 2 :

'''
Print numbers from 1 to 10 

Solution :

for i in range(1,11):
    print(i)
    
#range() is function in python

'''


#While Loop
'''
#While loop

i = 1

while i <= 5:
    print(i)
    i=i+1
    

'''