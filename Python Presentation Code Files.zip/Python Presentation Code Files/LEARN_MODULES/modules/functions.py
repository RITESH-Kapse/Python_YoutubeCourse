def calculate_triangle_area(base,height):
    return 1/2 * (base*height)

def calculate_square_area(length):
    return length*length

