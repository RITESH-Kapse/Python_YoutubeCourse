import functions as f

'''
Since this main.py file is inside modules folder -- same level of functions.py , 
we can directly call "import functions as f"
'''

area = f.calculate_square_area(10)
print(area)

triangle_area = f.calculate_triangle_area(10,30)
print(triangle_area)