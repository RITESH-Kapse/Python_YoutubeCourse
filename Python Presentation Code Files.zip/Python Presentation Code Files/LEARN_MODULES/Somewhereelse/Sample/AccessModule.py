import sys
sys.path.append(r"C:\Users\rkapse\Desktop\Python Sessions\Python Presentation Code Files\LEARN_MODULES\modules")

# r in front of the string with your actual path denotes a raw string.

import functions as f

area = f.calculate_square_area(5)
print(area)