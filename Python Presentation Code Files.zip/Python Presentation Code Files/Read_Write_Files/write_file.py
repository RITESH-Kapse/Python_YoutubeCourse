f =  open(r"C:\Users\rkapse\Desktop\NCG Training Material - August 2022\Python Sessions\Python Presentation Code Files\Read_Write_Files\sample.text","a")
f.write("\n Lets learn today")
f.close()


# r - read only
# w - write only
# r+ - both read and write
# w+ - both read and write and if file doesnt exist , it will create new file. If exists, then overwrites
# a - Open file in append mode . Original content will not be overwritten.

# If we dont want to use open - close file statements , we can use with statement.

