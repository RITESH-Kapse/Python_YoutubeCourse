f=open(r"C:\Users\rkapse\Desktop\NCG Training Material - August 2022\Python Sessions\Python Presentation Code Files\Read_Write_Files\read_file.txt","r")

f_out = open(r"C:\Users\rkapse\Desktop\NCG Training Material - August 2022\Python Sessions\Python Presentation Code Files\Read_Write_Files\output_file.txt","w")

for line in f:
    words = line.split(' ') # This will create a list by taking all the words in the line.
    print(words)

    f_out.write("wordcount: "+ str(len(words)) + line)

f.close()
f_out.close()

    

