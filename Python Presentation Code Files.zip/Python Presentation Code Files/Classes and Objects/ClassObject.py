'''
What 'self' essentailly is, is the class, so when referring to 'self'
you are refering to values in a class.

So 'self.color = 'color' is just adding a variable in the
class which has the same value as 'age'.

'''
#Creating class 
class Car:
    # Class has different methods as below  init, drive, speaks etc and properties are name and color
    def __init__(self,name,color):
        self.name = name
        self.color = color

    def drive(self):
        if self.color == "red":
            print(self.name, "is of color red")
        elif self.color == "yellow":
            print(self.name, "is of color yellow")

    def speaks(self):
        print(self.name, "has chat bot who answers the questions !")


#creating instances of class / creating objects
#Self is always passed so no need to pass seperately. Pass only two arguments
honda = Car("hondacity", "red")

honda.drive()
honda.speaks()

MG = Car("Astor", "yellow")

MG.drive()
MG.speaks()